#!/bin/sh -e
./bmzip-test.sh
